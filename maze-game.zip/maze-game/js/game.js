import { db, GAME } from './firebase-config.js';
import { ref, get, update, runTransaction, push, set } from "https://www.gstatic.com/firebasejs/13.3.0/firebase-database.js";

// =========================================
// 1. حالة اللعبة (Game State)
// =========================================
let currentUser = null; // بيانات اللاعب الحالي
let currentBets = {};   // الرهانات الحالية { 1: 50, 3: 100 }
let timerInterval = null;
let currentTime = GAME.ROUND_SECONDS;
let isRoundActive = false;

// عناصر الواجهة
const timerDisplay = document.getElementById('timerDisplay');
const gameButtons = document.querySelectorAll('.game-btn');
const quickBetBtns = document.querySelectorAll('.quick-bet-btn');
const customBetInput = document.getElementById('customBetInput');
const startBtn = document.getElementById('startBtn');
const userNameDisplay = document.getElementById('userName');
const userIdDisplay = document.getElementById('userId');

// =========================================
// 2. دوال مساعدة للواجهة
// =========================================
function updateTimerDisplay(seconds) {
    timerDisplay.innerText = seconds;
    if (seconds <= 10 && isRoundActive) {
        timerDisplay.style.color = '#ef4444'; // أحمر في العشر ثواني الأخيرة
    } else {
        timerDisplay.style.color = '#38bdf8'; // أزرق افتراضي
    }
}

function resetButtons() {
    gameButtons.forEach(btn => {
        btn.classList.remove('active');
        btn.querySelector('.btn-bet-amount').innerText = '0';
    });
    currentBets = {};
    customBetInput.value = '';
}

function getTotalBet() {
    return Object.values(currentBets).reduce((a, b) => a + b, 0);
}

// =========================================
// 3. التفاعل مع الأزرار
// =========================================

// اختيار زر من الأزرار الثمانية
gameButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        if (!isRoundActive) {
            alert("انتظر بدء الجولة القادمة لوضع الرهانات!");
            return;
        }

        const index = btn.getAttribute('data-index');
        const betAmount = parseInt(customBetInput.value);

        // إذا كان اللاعب يريد إلغاء الرهان على هذا الزر
        if (currentBets[index]) {
            delete currentBets[index];
            btn.classList.remove('active');
            btn.querySelector('.btn-bet-amount').innerText = '0';
            return;
        }

        // التحقق من عدد الأزرار (حد أقصى 2)
        if (Object.keys(currentBets).length >= 2) {
            alert("لا يمكنك اختيار أكثر من زرين في الجولة الواحدة!");
            return;
        }

        // التحقق من إدخال مبلغ
        if (!betAmount || betAmount < GAME.MIN_BET) {
            alert(`يرجى إدخال مبلغ رهان صحيح (أدنى رهان ${GAME.MIN_BET})`);
            customBetInput.focus();
            return;
        }

        // التحقق من الرصيد (سيتم ربطه بالرصيد الحقيقي لاحقاً)
        const currentTotal = getTotalBet();
        if (currentTotal + betAmount > (currentUser?.balance || 0)) {
            alert("رصيدك غير كافٍ لهذا الرهان!");
            return;
        }

        // تسجيل الرهان
        currentBets[index] = betAmount;
        btn.classList.add('active');
        btn.querySelector('.btn-bet-amount').innerText = betAmount;
        customBetInput.value = ''; // تفريغ الحقل للرهان التالي
    });
});

// أزرار الرهان السريع
quickBetBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const amount = btn.getAttribute('data-amount');
        customBetInput.value = amount;
    });
});

// =========================================
// 4. منطق الجولة (Round Logic)
// =========================================

function startNewRound() {
    isRoundActive = true;
    currentTime = GAME.ROUND_SECONDS;
    resetButtons();
    updateTimerDisplay(currentTime);
    startBtn.innerText = "جاري اللعب...";
    startBtn.disabled = true;
    startBtn.style.opacity = "0.5";

    timerInterval = setInterval(() => {
        currentTime--;
        updateTimerDisplay(currentTime);

        // عند الوصول لـ 15 ثانية (نهاية وقت الرهان)
        if (currentTime === GAME.RESULT_SECONDS) {
            startBtn.innerText = "إعلان النتائج...";
            executeGameResult(); // تنفيذ النتيجة وإظهار الفائز
        }

        // عند انتهاء الجولة بالكامل
        if (currentTime <= 0) {
            clearInterval(timerInterval);
            isRoundActive = false;
            startBtn.innerText = "START";
            startBtn.disabled = false;
            startBtn.style.opacity = "1";
            
            // بدء الجولة التالية تلقائياً (كما طلبت)
            setTimeout(() => {
                startNewRound();
            }, 2000);
        }
    }, 1000);
}

// زر البدء اليدوي
startBtn.addEventListener('click', () => {
    if (!isRoundActive) {
        startNewRound();
    }
});

// =========================================
// 5. منطق Firebase (النتائج والفوز والخسارة)
// =========================================

async function executeGameResult() {
    const totalBet = getTotalBet();
    if (totalBet === 0) {
        console.log("لم يقم اللاعب بوضع رهانات هذه الجولة.");
        return; 
    }

    try {
        const poolRef = ref(db, 'pool/balance');
        const poolSnap = await get(poolRef);
        let currentPool = poolSnap.exists() ? poolSnap.val() : 0;

        // 1. اللعبة تأخذ 25% وتضيف 75% للصندوق
        const gameCut = totalBet * GAME.GAME_CUT;
        const poolShare = totalBet * GAME.POOL_SHARE;
        
        let newPoolBalance = currentPool + poolShare;
        
        // حفظ الأرباح للعبة
        await update(ref(db, 'admin_stats'), {
            totalGameProfit: (gameCut + (currentPool || 0)) 
        });

        // 2. تحديد الفائز
        let winningButton = null;
        const selectedButtons = Object.keys(currentBets);
        
        // نختار الزر الذي راهن عليه اللاعب
        const randomSelectedIndex = selectedButtons[Math.floor(Math.random() * selectedButtons.length)];
        const betAmountOnSelected = currentBets[randomSelectedIndex];
        const potentialWin = betAmountOnSelected * GAME.MULTIPLIER;

        // 3. التحقق من الصندوق (هل يكفي لدفع الجائزة؟)
        if (newPoolBalance >= potentialWin) {
            // الصندوق يكفي -> اللاعب يفوز
            winningButton = parseInt(randomSelectedIndex);
            newPoolBalance -= potentialWin;
            
            // إضافة المكسب لرصيد اللاعب (تحديث وهمي للتوضيح، سيتم ربطه لاحقاً)
            if(currentUser) {
                currentUser.balance += potentialWin;
            }
            alert(`🎉 مبروك! فزت بمبلغ ${potentialWin} ماسة.`);
        } else {
            // الصندوق لا يكفي -> النظام يختار زر لم يختره اللاعب ليخسر
            winningButton = Math.floor(Math.random() * 8) + 1; // من 1 لـ 8
            while (selectedButtons.includes(winningButton.toString())) {
                winningButton = Math.floor(Math.random() * 8) + 1;
            }
            alert(`❌ للأسف، الزر الفائز هو ${winningButton}.`);
        }

        // تحديث رصيد الصندوق في Firebase
        await update(ref(db, 'pool'), { balance: newPoolBalance });

        // إظهار الزر الفائز (تأثير بصري)
        gameButtons.forEach(btn => {
            if (parseInt(btn.getAttribute('data-index')) === winningButton) {
                btn.style.boxShadow = "0 0 30px #fbbf24"; // توهج ذهبي للفائز
                btn.style.transform = "scale(1.1)";
            } else {
                btn.style.boxShadow = "none";
                btn.style.transform = "scale(1)";
            }
        });

    } catch (error) {
        console.error("خطأ في تنفيذ نتيجة الجولة:", error);
    }
}

// =========================================
// 6. التهيئة الأولية (Initialization)
// =========================================
// للتجربة: سنعطي اللاعب رصيداً مبدئياً لكي نستطيع اللعب
// في المرحلة القادمة سيتم جلب بياناته الحقيقية من شاشة تسجيل الدخول
currentUser = { id: "TEST123", name: "لاعب تجريبي", balance: 1000 };
userNameDisplay.innerText = currentUser.name;
userIdDisplay.innerText = "ID: " + currentUser.id;

// بدء الجولات تلقائياً عند فتح الصفحة
document.addEventListener("DOMContentLoaded", () => {
    startNewRound();
});