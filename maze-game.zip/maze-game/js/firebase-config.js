import { initializeApp } from "https://www.gstatic.com/firebasejs/13.3.0/firebase-app.js";
import { getDatabase, ref, set, get, update, push, onValue, runTransaction, query, orderByChild, equalTo } from "https://www.gstatic.com/firebasejs/13.3.0/firebase-database.js";

// إعدادات مشروعك
const firebaseConfig = {
  apiKey: "AIzaSyAp-tMO1n8SwnnWr1nXGIWpckALact9UYc",
  authDomain: "maze-game-7.firebaseapp.com",
  databaseURL: "https://maze-game-7-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "maze-game-7",
  storageBucket: "maze-game-7.firebasestorage.app",
  messagingSenderId: "948688357452",
  appId: "1:948688357452:web:4f21a537c6d7dfc9244ce9"
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);

// ============================================
// ثوابت اللعبة (تم ضبطها بناءً على اتفاقنا)
// ============================================
export const GAME = {
  VAULT_INITIAL: 20000000,      // الخزنة الابتدائية 20 مليون
  GAME_CUT: 0.25,               // 25% ربح اللعبة
  POOL_SHARE: 0.75,             // 75% للصندوق المشترك
  MULTIPLIER: 2,                // مضاعف الفوز (يحصل على ضعف رهان الزر الفائز)
  MIN_BET: 10,                  // أدنى رهان
  MIN_DEPOSIT: 40,              // أدنى إيداع 40 ماسة
  MASHA_PRICE_EGP: 1,           // 1 ماسة = 1 جنيه
  SUPPORT_WHATSAPP: "201065580651", // رقم الدعم
  AGENT_PHONE: "01036557245",       // رقم الوكيل
  BET_SECONDS: 15,              // 15 ثانية لوضع الرهانات
  RESULT_SECONDS: 10,           // 10 ثواني لإعلان النتائج
  ROUND_SECONDS: 25,            // إجمالي الجولة 25 ثانية
};

// دالة لفتح الواتساب
export function openWhatsApp(phone, message) {
  const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
  window.open(url, "_blank");
}